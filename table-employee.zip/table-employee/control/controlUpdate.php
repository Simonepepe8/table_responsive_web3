<?php
require 'db.php';

$id = $_POST['id'];
$first_name = trim($_POST['first_name']);
$last_name = trim($_POST['last_name']);
$email = trim($_POST['email']);
$position = trim($_POST['position']);
$gender = trim($_POST['gender']);

$stmt = $conn->prepare("UPDATE datatable SET first_name=?, last_name=?, email=?, position=?, gender=? WHERE id=?");
$stmt->bind_param("sssssi", $first_name, $last_name, $email, $position, $gender, $id);
$stmt->execute();
$stmt->close();

echo json_encode([
  'status' => 'success',
  'id' => $id,
  'name' => $first_name . ' ' . $last_name
]);
