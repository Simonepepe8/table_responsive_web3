<?php
require 'db.php'; // connect DB
header('Content-Type: application/json');

$id = $_POST['id'] ?? '';
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$email = $_POST['email'];
$position = $_POST['position'];
$gender = $_POST['gender'];

if ($id) {
  // แก้ไข
  $stmt = $conn->prepare("UPDATE datatable SET first_name=?, last_name=?, email=?, position=?, gender=? WHERE id=?");
  $stmt->bind_param("sssssi", $first_name, $last_name, $email, $position, $gender, $id);
  $stmt->execute();
  echo json_encode([
    "status" => "success",
    "message" => "Updated",
    "id" => $id,
    "first_name" => $first_name,
    "last_name" => $last_name
  ]);
} else {
  // เพิ่มใหม่
  $stmt = $conn->prepare("INSERT INTO datatable (first_name, last_name, email, position, gender) VALUES (?, ?, ?, ?, ?)");
  $stmt->bind_param("sssss", $first_name, $last_name, $email, $position, $gender);
  $stmt->execute();
  echo json_encode([
    "status" => "success",
    "message" => "Inserted",
    "id" => $stmt->insert_id,
    "first_name" => $first_name,
    "last_name" => $last_name
  ]);
}
