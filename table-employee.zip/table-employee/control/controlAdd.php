<?php
// require 'db.php';

// // สมมติว่ามีการเชื่อมต่อฐานข้อมูล ($conn) ไว้แล้ว

// // กำหนดไดเรกทอรีที่จะเก็บรูปภาพที่อัปโหลด
// // ตรวจสอบให้แน่ใจว่าไดเรกทอรีนี้มีอยู่และเว็บเซิร์ฟเวอร์สามารถเขียนได้
// $target_dir = "uploads/"; // ตัวอย่าง: สร้างโฟลเดอร์ชื่อ 'uploads' ใน root ของโปรเจกต์คุณ

// if ($_SERVER['REQUEST_METHOD'] == 'POST') {
//     $id = intval($_POST['id']);
    
//     $first = trim($_POST['first_name']);
//     if (!preg_match('/^[A-Za-z\s]+$/', $first)) {
//         echo json_encode(['error' => 'Invalid first name']);
//         exit;
//     }
//     $last = trim($_POST['last_name']);
//     if (!preg_match('/^[A-Za-z\s]+$/', $last)) {
//         echo json_encode(['error' => 'Invalid last name']);
//         exit;
//     }
//     $email = trim($_POST['email']);
//     if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
//         echo json_encode(['error' => 'Invalid email']);
//         exit;
//     }
//     $position = trim($_POST['position']);
//     $gender = trim($_POST['gender']);
//     if ($gender === 'Other') {
//         $gender = trim($_POST['otherGender']);
//     }

// $sql = "INSERT INTO datatable (first_name, last_name, email, position, gender, image_avatar)
//         VALUES (?, ?, ?, ?, ?, ?)";

// if ($stmt = $conn->prepare($sql)) {
//     // ผูกค่าตัวแปรเข้ากับ placeholder (s = string)
//     $stmt->bind_param("ssssss", $first, $last, $email, $position, $gender, $image_avatar_filename);

//     if ($stmt->execute()) {
//         echo "สร้างรายการใหม่สำเร็จ";
//     } else {
//         echo "เกิดข้อผิดพลาด: " . $stmt->error;
//     }
//     $stmt->close(); // ปิด statement
// } else {
//     echo "เกิดข้อผิดพลาดในการเตรียม statement: " . $conn->error;
// }

//     $conn->close();
// }

require 'db.php'; // ไฟล์นี้ควรมีการเชื่อมต่อฐานข้อมูล ($conn)

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 1. รับและทำความสะอาด/ตรวจสอบข้อมูลจากฟอร์ม
    // ส่วนนี้เหมือนกับที่คุณมีอยู่แล้ว
    $id = intval($_POST['id']); // ถ้าใช้สำหรับการอัปเดต ต้องใช้ ID นี้
    $first = trim($_POST['first_name']);
    $last = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $position = trim($_POST['position']);
    $gender = trim($_POST['gender']);
    if ($gender === 'Other') {
        $gender = trim($_POST['otherGender']);
    }

    // 2. รับชื่อไฟล์รูปภาพ (สมมติว่าไฟล์ถูกอัปโหลดและย้ายไปยัง 'uploads/' แล้ว)
    // หรือถ้ายังไม่ได้อัปโหลดจริง แค่ส่งชื่อไฟล์มาก็ได้
    $image_avatar_filename = null; // ตั้งค่าเริ่มต้นเป็น null

    // ตรวจสอบว่ามีไฟล์ถูกอัปโหลดมาหรือไม่
    if (isset($_FILES['image_avatar']) && $_FILES['image_avatar']['error'] == UPLOAD_ERR_OK) {
        // สร้างชื่อไฟล์ที่ไม่ซ้ำกันเพื่อบันทึกลงฐานข้อมูล
        // ในสถานการณ์จริง คุณจะต้องมีโค้ด PHP สำหรับย้ายไฟล์ไปยังโฟลเดอร์ 'uploads/'
        // แต่ในที่นี้ เราจะใช้แค่ชื่อไฟล์เพื่อบันทึกลง DB เท่านั้น
        $file_extension = strtolower(pathinfo($_FILES['image_avatar']['name'], PATHINFO_EXTENSION));
        $image_avatar_filename = uniqid() . "." . $file_extension;

        // **หมายเหตุสำคัญ:** โค้ดด้านล่างนี้จำเป็นต้องมีเพื่อย้ายไฟล์จริง!
        // ถ้าไม่มีส่วนนี้ ไฟล์จะยังอยู่ในโฟลเดอร์ชั่วคราวและจะหายไป
        $target_dir = "uploads/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true); // สร้างโฟลเดอร์ถ้าไม่มี
        }
        $target_file_path = $target_dir . $image_avatar_filename;

        if (!move_uploaded_file($_FILES['image_avatar']['tmp_name'], $target_file_path)) {
            // หากย้ายไฟล์ไม่ได้ ให้จัดการข้อผิดพลาด
            echo json_encode(['error' => 'Failed to upload image.']);
            exit;
        }
    } else {
        // ถ้าไม่มีการอัปโหลดไฟล์ หรือมีข้อผิดพลาดในการอัปโหลด
        // คุณอาจต้องการตั้งค่า image_avatar_filename เป็นค่าเริ่มต้น หรือจัดการใน UI
        $image_avatar_filename = null; // หรือค่าว่างสตริง ''
    }

    // 3. เตรียม SQL Statement สำหรับ INSERT
    $sql = "INSERT INTO datatable (first_name, last_name, email, position, Gender, image_avatar)
            VALUES (?, ?, ?, ?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        // 4. ผูกค่าตัวแปรกับ Placeholder
        // 'ssssss' คือประเภทข้อมูลของแต่ละ parameter (string, string, string, ...)
        $stmt->bind_param("ssssss", $first, $last, $email, $position, $gender, $image_avatar_filename);

        // 5. รัน Statement
        if ($stmt->execute()) {
            echo "สร้างรายการใหม่สำเร็จ";
        } else {
            echo "เกิดข้อผิดพลาดในการบันทึกข้อมูล: " . $stmt->error;
        }
        $stmt->close(); // ปิด statement
    } else {
        echo "เกิดข้อผิดพลาดในการเตรียม statement: " . $conn->error;
    }

    $conn->close(); // ปิดการเชื่อมต่อฐานข้อมูล
}
?>

<form class="row g-3 needs-validation" id="crudForm" novalidate enctype="multipart/form-data">
  <input type="hidden" id="empId" name="id" value="">

  <div class="col-md-6 position-relative">
    <label for="image_avatar" class="form-label">Avatar</label>
    <input type="file" class="form-control" id="image_avatar" name="image_avatar" required>
    <div class="invalid-tooltip">
      กรุณาเลือกไฟล์รูปภาพ
    </div>
  </div>

  <div class="col-md-6 position-relative">
    <label for="first_name" class="form-label">First Name</label>
    <input type="text" class="form-control" id="first_name" name="first_name" required pattern="^[A-Za-z\s]+$">
    <div class="invalid-tooltip">
      กรุณากรอกชื่อเป็นภาษาอังกฤษเท่านั้น
    </div>
  </div>

  <div class="col-md-6 position-relative">
    <label for="last_name" class="form-label">Last Name</label>
    <input type="text" class="form-control" id="last_name" name="last_name" required pattern="^[A-Za-z\s]+$">
    <div class="invalid-tooltip">
      กรุณากรอกนามสกุลเป็นภาษาอังกฤษเท่านั้น
    </div>
  </div>

  <div class="col-md-6 position-relative">
    <label for="email" class="form-label">Email</label>
    <input type="email" class="form-control" id="email" name="email" required>
    <div class="invalid-tooltip">
      กรุณากรอกอีเมลให้ถูกต้อง
    </div>
  </div>

  <div class="col-md-6 position-relative">
    <label for="position" class="form-label">Position</label>
    <input type="text" class="form-control" id="position" name="position" required>
    <div class="invalid-tooltip">
      กรุณาระบุตำแหน่ง
    </div>
  </div>

  <div class="col-md-6 position-relativae">
    <label for="gender" class="form-label">Gender</label>
    <select class="form-select" id="gender" name="gender" onchange="checkGender()">
      <option selected disabled value="">เลือกเพศ...</option>
      <option value="Male">ชาย</option>
      <option value="Female">หญิง</option>
      <option value="Other">อื่นๆ</option>
    </select>
    
    <div id="otherGender" style="display: none;">
      <label for="otherGenderInput" class="form-label">ระบุเพศอื่นๆ</label>
      <input type="text" class="form-control" id="otherGenderInput" name="otherGender">
    </div>
    <div class="invalid-tooltip">
      กรุณาเลือกเพศ
    </div>
  </div>

  <div class="col-12">
    <button class="btn btn-primary" type="submitadd">บันทึก</button>
  </div>
</form>
<script>
  function checkGender() {
    var genderSelect = document.getElementById("gender");
    var otherGenderDiv = document.getElementById("otherGender");
    if (genderSelect.value === "Other") {
      otherGenderDiv.style.display = "block";
    } else {
      otherGenderDiv.style.display = "none";
    }
  }
</script>