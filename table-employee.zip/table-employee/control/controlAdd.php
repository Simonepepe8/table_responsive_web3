<?php
require 'db.php';

// สมมติว่ามีการเชื่อมต่อฐานข้อมูล ($conn) ไว้แล้ว

// กำหนดไดเรกทอรีที่จะเก็บรูปภาพที่อัปโหลด
// ตรวจสอบให้แน่ใจว่าไดเรกทอรีนี้มีอยู่และเว็บเซิร์ฟเวอร์สามารถเขียนได้
$target_dir = "uploads/"; // ตัวอย่าง: สร้างโฟลเดอร์ชื่อ 'uploads' ใน root ของโปรเจกต์คุณ

// สร้างโฟลเดอร์ uploads หากยังไม่มี
if (!is_dir($target_dir)) {
    mkdir($target_dir, 5500, true); // สร้างโฟลเดอร์และกำหนดสิทธิ์ (ระมัดระวังเรื่องสิทธิ์ใน production)
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = intval($_POST['id']);
    
    $first = trim($_POST['first_name']);
    if (!preg_match('/^[A-Za-z\s]+$/', $first)) {
        echo json_encode(['error' => 'Invalid first name']);
        exit;
    }
    $last = trim($_POST['last_name']);
    if (!preg_match('/^[A-Za-z\s]+$/', $last)) {
        echo json_encode(['error' => 'Invalid last name']);
        exit;
    }
    $email = trim($_POST['email']);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['error' => 'Invalid email']);
        exit;
    }
    $position = trim($_POST['position']);
    $gender = trim($_POST['gender']);
    if ($gender === 'Other') {
        $gender = trim($_POST['otherGender']);
    }

    $image_avatar_filename = ''; // เริ่มต้นด้วยสตริงว่างเปล่าสำหรับชื่อไฟล์รูปภาพ

// ตรวจสอบว่ามีการอัปโหลดไฟล์และไม่มีข้อผิดพลาด
if (isset($_FILES["image_avatar"]) && $_FILES["image_avatar"]["error"] == 0) {
    $target_file = $target_dir . basename($_FILES["image_avatar"]["name"]); // พาธของไฟล์ที่จะเก็บ
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION)); // นามสกุลไฟล์

    // ตรวจสอบว่าเป็นไฟล์รูปภาพจริงหรือไม่
    $check = getimagesize($_FILES["image_avatar"]["tmp_name"]);
    if ($check !== false) {
        // echo "ไฟล์เป็นรูปภาพ - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "ไฟล์ไม่ใช่รูปภาพ.";
        $uploadOk = 0;
    }

    // ตรวจสอบว่าไฟล์มีอยู่แล้วหรือไม่ (ไม่บังคับ อาจต้องการเปลี่ยนชื่อไฟล์แทน)
    // if (file_exists($target_file)) {
    //     echo "ขออภัย, ไฟล์นี้มีอยู่แล้ว.";
    //     $uploadOk = 0;
    // }

    // ตรวจสอบขนาดไฟล์ (ตัวอย่าง: ไม่เกิน 5MB)
    if ($_FILES["image_avatar"]["size"] > 5000000) { // 5000000 bytes = 5MB
        echo "ขออภัย, ไฟล์ของคุณมีขนาดใหญ่เกินไป.";
        $uploadOk = 0;
    }

    // อนุญาตเฉพาะบางนามสกุลไฟล์
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
        echo "ขออภัย, อนุญาตเฉพาะไฟล์ JPG, JPEG, PNG และ GIF เท่านั้น.";
        $uploadOk = 0;
    }

    // ตรวจสอบว่า $uploadOk ถูกตั้งค่าเป็น 0 โดยข้อผิดพลาดหรือไม่
    if ($uploadOk == 0) {
        echo "ขออภัย, ไฟล์ของคุณไม่ได้รับการอัปโหลด.";
    // หากทุกอย่างเรียบร้อย ลองอัปโหลดไฟล์
    } else {
        // ย้ายไฟล์จากที่พักชั่วคราวไปยังโฟลเดอร์เป้าหมาย
        if (move_uploaded_file($_FILES["image_avatar"]["tmp_name"], $target_file)) {
            // อัปโหลดไฟล์สำเร็จ, เก็บชื่อไฟล์/พาธลงในฐานข้อมูล
            $image_avatar_filename = basename($_FILES["image_avatar"]["name"]);
            echo "ไฟล์ ". htmlspecialchars( basename( $_FILES["image_avatar"]["name"])). " ได้รับการอัปโหลดแล้ว.";
        } else {
            echo "ขออภัย, เกิดข้อผิดพลาดในการอัปโหลดไฟล์ของคุณ.";
        }
    }
}

// --- การบันทึกข้อมูลลงฐานข้อมูล ---
// ตรวจสอบให้แน่ใจว่าตาราง 'datatable' ของคุณมีคอลัมน์ (เช่น VARCHAR) สำหรับ 'image_avatar'
// ที่สามารถเก็บชื่อไฟล์/พาธได้
// **สำคัญ: ใช้ Prepared Statements เพื่อป้องกัน SQL Injection!**
$sql = "INSERT INTO datatable (first_name, last_name, email, position, gender, image_avatar)
        VALUES (?, ?, ?, ?, ?, ?)";

if ($stmt = $conn->prepare($sql)) {
    // ผูกค่าตัวแปรเข้ากับ placeholder (s = string)
    $stmt->bind_param("ssssss", $first, $last, $email, $position, $gender, $image_avatar_filename);

    if ($stmt->execute()) {
        echo "สร้างรายการใหม่สำเร็จ";
    } else {
        echo "เกิดข้อผิดพลาด: " . $stmt->error;
    }
    $stmt->close(); // ปิด statement
} else {
    echo "เกิดข้อผิดพลาดในการเตรียม statement: " . $conn->error;
}

    $conn->close();
}
?>

<form class="row g-3 needs-validation" id="crudForm" novalidate enctype="multipart/form-data">
  <input type="hidden" id="empId" name="id" value="">

  <div class="col-md-6 position-relative">
    <label for="image_avatar" class="form-label">Avatar</label>
    <input type="file" class="form-control" id="image_avatar" name="image_avatar" required>
    <div class="invalid-tooltip">
      กรุณาเลือกไฟล์รูปภาพ
    </div>
  </div>

  <div class="col-md-6 position-relative">
    <label for="first_name" class="form-label">First Name</label>
    <input type="text" class="form-control" id="first_name" name="first_name" required pattern="^[A-Za-z\s]+$">
    <div class="invalid-tooltip">
      กรุณากรอกชื่อเป็นภาษาอังกฤษเท่านั้น
    </div>
  </div>

  <div class="col-md-6 position-relative">
    <label for="last_name" class="form-label">Last Name</label>
    <input type="text" class="form-control" id="last_name" name="last_name" required pattern="^[A-Za-z\s]+$">
    <div class="invalid-tooltip">
      กรุณากรอกนามสกุลเป็นภาษาอังกฤษเท่านั้น
    </div>
  </div>

  <div class="col-md-6 position-relative">
    <label for="email" class="form-label">Email</label>
    <input type="email" class="form-control" id="email" name="email" required>
    <div class="invalid-tooltip">
      กรุณากรอกอีเมลให้ถูกต้อง
    </div>
  </div>

  <div class="col-md-6 position-relative">
    <label for="position" class="form-label">Position</label>
    <input type="text" class="form-control" id="position" name="position" required>
    <div class="invalid-tooltip">
      กรุณาระบุตำแหน่ง
    </div>
  </div>

  <div class="col-md-6 position-relativae">
    <label for="gender" class="form-label">Gender</label>
    <select class="form-select" id="gender" name="gender" onchange="checkGender()">
      <option selected disabled value="">เลือกเพศ...</option>
      <option value="Male">ชาย</option>
      <option value="Female">หญิง</option>
      <option value="Other">อื่นๆ</option>
    </select>
    
    <div id="otherGender" style="display: none;">
      <label for="otherGenderInput" class="form-label">ระบุเพศอื่นๆ</label>
      <input type="text" class="form-control" id="otherGenderInput" name="otherGender">
    </div>
    <div class="invalid-tooltip">
      กรุณาเลือกเพศ
    </div>
  </div>

  <div class="col-12">
    <button class="btn btn-primary" type="submitadd">บันทึก</button>
  </div>
</form>
<script>
  function checkGender() {
    var genderSelect = document.getElementById("gender");
    var otherGenderDiv = document.getElementById("otherGender");
    if (genderSelect.value === "Other") {
      otherGenderDiv.style.display = "block";
    } else {
      otherGenderDiv.style.display = "none";
    }
  }
</script>