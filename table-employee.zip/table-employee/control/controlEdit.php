<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$id = intval($_POST['id']);

    $first = trim($_POST['first_name']);
    if (!preg_match('/^[A-Za-z\s]+$/', $first)) {
        echo json_encode(['error' => 'Invalid first name']);
        exit;
    }
    $last = trim($_POST['last_name']);
    if (!preg_match('/^[A-Za-z\s]+$/', $last)) {
        echo json_encode(['error' => 'Invalid last name']);
        exit;
    }
    $email = trim($_POST['email']);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['error' => 'Invalid email']);
        exit;
    }
    $position = trim($_POST['position']);
    $gender = trim($_POST['gender']);
    if ($gender === 'Other') {
        $gender = trim($_POST['otherGender']);
    }

    $stmt = $conn->prepare("UPDATE datatable SET first_name = ?, last_name = ?, email = ?, position = ?, gender = ? WHERE id = ?");
    $stmt->bind_param("sssssi", $first, $last, $email, $position, $gender, $id);
    $stmt->execute();
    $stmt->close();
    $conn->close();
}
?>
<form id="editForm" class="needs-validation" novalidate>
  <input type="hidden" id="empId" name="id" value="<?= $data['id'] ?>">

  <div class="mb-3 position-relative">
    <label for="editFirstName" class="form-label">ชื่อ</label>
    <input type="text" class="form-control" id="editFirstName" name="first_name" value="<?= htmlspecialchars($data['first_name']) ?>" pattern="^[A-Za-z]+$" required>
    <div class="invalid-tooltip">ชื่อควรเป็นภาษาอังกฤษเท่านั้น</div>
  </div>

  <div class="mb-3 position-relative">
    <label for="editLastName" class="form-label">นามสกุล</label>
    <input type="text" class="form-control" id="editLastName" name="last_name" value="<?= htmlspecialchars($data['last_name']) ?>" pattern="^[A-Za-z]+$" required>
    <div class="invalid-tooltip">นามสกุลควรเป็นภาษาอังกฤษเท่านั้น</div>
  </div>

  <div class="mb-3 position-relative">
    <label for="editEmail" class="form-label">Email</label>
    <input type="email" class="form-control" id="editEmail" name="email" value="<?= htmlspecialchars($data['email']) ?>" required>
    <div class="invalid-tooltip">กรุณากรอกอีเมลให้ถูกต้อง</div>
  </div>

  <div class="mb-3 position-relative">
    <label for="editPosition" class="form-label">ตำแหน่ง</label>
    <input type="text" class="form-control" id="editPosition" name="position" value="<?= htmlspecialchars($data['position']) ?>" required>
    <div class="invalid-tooltip">กรุณากรอกตำแหน่ง</div>
  </div>

  <div class="col-md-6 position-relativae">
    <label for="gender" class="form-label">Gender</label>
    <select class="form-select" id="gender" name="gender" onchange="checkGender()">
      <option selected disabled value="">เลือกเพศ...</option>
      <option value="Male">ชาย</option>
      <option value="Female">หญิง</option>
      <option value="Other">อื่นๆ</option>
    </select>
    
    <div id="otherGender" style="display: none;">
      <label for="otherGenderInput" class="form-label">ระบุเพศอื่นๆ</label>
      <input type="text" class="form-control" id="otherGenderInput" name="otherGender">
    </div>
    <div class="invalid-tooltip">
      กรุณาเลือกเพศ
    </div>
  </div>

  <div class="col-12">
    <button class="btn btn-primary" type="submitadd">บันทึก</button>
  </div>
</form>


  <button type="submit" class="btn btn-primary w-100">บันทึกการแก้ไข</button>
</form>
<script>
  function checkGender() {
    var genderSelect = document.getElementById("gender");
    var otherGenderDiv = document.getElementById("otherGender");
    if (genderSelect.value === "Other") {
      otherGenderDiv.style.display = "block";
    } else {
      otherGenderDiv.style.display = "none";
    }
  }
</script>