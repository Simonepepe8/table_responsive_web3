<?php
require '../control/controlEdit.php';
?>

