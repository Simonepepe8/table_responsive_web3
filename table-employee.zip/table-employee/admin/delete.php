<?php
require '../control/controlDelete.php';
?>