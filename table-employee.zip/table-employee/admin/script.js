$(document).ready(function () {
  const table = $('#employeeTable').DataTable({
    processing: true,
    serverSide: true,
    ajax: {
      url: 'server_processing.php',
      type: 'POST'
    },
    columns: [
      { data: 'id' },
      { data: 'first_name' },
      { data: 'last_name' },
      { data: 'email' },
      { data: 'position' },
      { data: 'gender' },
      { data: 'image_avatar' },
      {
        data: null,
        render: function (data) {
          return `
            <a href="#" class="btn-table btn-edit"
               data-id="${data.id}"
               data-fname="${data.first_name}"
               data-lname="${data.last_name}"
               data-email="${data.email}"
               data-position="${data.position}"
               data-gender="${data.gender}" 
               data-image_avatar="${data.image_avatar}">
              แก้ไข
            </a>
            <a href="#" class="btn-table btn-delete"
               data-id="${data.id}"
               data-name="${data.first_name} ${data.last_name}">
              ลบ
            </a>
          `;
        }
      }
    ]
  });

  // ✅ Bootstrap 5 Validation
  (() => {
    'use strict';
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
      form.addEventListener('submit', event => {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  })();

  // ✅ Submit Add/Edit
  $('#crudForm').submit(function (e) {
    e.preventDefault();
    const form = this;

    if (!form.checkValidity()) {
      e.stopPropagation();
      form.classList.add('was-validated');
      return;
    }

    const id = $('#empId').val();
    const url = id ? 'edit.php' : 'add.php';
    const formData = $(form).serialize();

    $.ajax({
      url: url,
      type: 'POST',
      data: formData,
      success: function () {
        $('#exampleModal').modal('hide');
        table.ajax.reload();

        const first = $('#first_name').val();
        const last = $('#last_name').val();
        const fullName = `${first} ${last}`;

        Swal.fire({
          icon: 'success',
          title: id ? `แก้ไขพนักงานรหัส ${id} เป็น ${fullName} แล้ว` : `เพิ่ม ${fullName} เรียบร้อย`,
          showConfirmButton: false,
          timer: 2000
        });

        form.reset();
        $('#empId').val('');
        form.classList.remove('was-validated');
      }
    });
  });

  // ✅ Fill Data to Form When Click Edit
  $('#employeeTable').on('click', '.btn-edit', function () {
    const btn = $(this);
    $('#empId').val(btn.data('id'));
    $('#first_name').val(btn.data('fname'));
    $('#last_name').val(btn.data('lname'));
    $('#email').val(btn.data('email'));
    $('#position').val(btn.data('position'));
    $('#gender').val(btn.data('gender'));
    $('#exampleModal').modal('show');
  });

  // ✅ SweetAlert Delete
  $('#employeeTable').on('click', '.btn-delete', function () {
    const id = $(this).data('id');
    const name = $(this).data('name');

    Swal.fire({
      title: `ลบ ${name}?`,
      text: "คุณแน่ใจหรือไม่ว่าจะลบข้อมูลนี้",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'ลบเลย!',
      cancelButtonText: 'ยกเลิก',
      reverseButtons: true,
      buttonsStyling: false,
      customClass: {
        confirmButton: 'btn btn-danger mx-2',
        cancelButton: 'btn btn-secondary mx-2',
        actions: 'swal2-buttons-row'
      },
    }).then((result) => {
      if (result.isConfirmed) {
        $.post('delete.php', { id }, function () {
          table.ajax.reload();
          Swal.fire('ลบแล้ว!', `ลบพนักงาน ${name} ลำดับที่ ${id} เรียบร้อย`, 'success');
        }).fail(() => {
          Swal.fire('ผิดพลาด', 'ลบไม่สำเร็จ', 'error');
        });
      }
    });
  });
});