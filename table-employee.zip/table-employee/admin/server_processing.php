<?php
require '../control/db.php';

$start  = $_POST['start'] ?? 0;
$length = $_POST['length'] ?? 10;
$search = $_POST['search']['value'] ?? '';
$gender = $_POST['gender'] ?? '';

// กำหนด columns ที่รองรับสำหรับ sorting (ต้องตรงกับ columns ใน DataTable)
$columns = ['id', 'first_name', 'last_name', 'email', 'position', 'gender'];

// ดึงค่าการ sort จาก DataTables
$orderColumnIndex = $_POST['order'][0]['column'] ?? 0;
$orderDir = $_POST['order'][0]['dir'] ?? 'asc';
$orderColumn = $columns[$orderColumnIndex] ?? 'id';

// เริ่มต้น query
$baseQuery = "FROM datatable WHERE 1=1";

// Filter by search
if ($search != '') {
  $search = mysqli_real_escape_string($conn, $search);
  $baseQuery .= " AND (first_name LIKE '%$search%' OR last_name LIKE '%$search%' OR email LIKE '%$search%')";
}

// Filter by gender
if ($gender != '') {
  $gender = mysqli_real_escape_string($conn, $gender);
  $baseQuery .= " AND gender = '$gender'";
}

// Get total filtered records (ก่อน LIMIT)
$resTotal = mysqli_query($conn, "SELECT COUNT(*) as total $baseQuery");
$totalFiltered = mysqli_fetch_assoc($resTotal)['total'];

// สร้างคำสั่ง SQL พร้อม ORDER BY และ LIMIT
$dataQuery = "SELECT id, first_name, last_name, email, position, gender $baseQuery ORDER BY $orderColumn $orderDir LIMIT $start, $length";
$resData = mysqli_query($conn, $dataQuery);

$data = [];
while ($row = mysqli_fetch_assoc($resData)) {
  $data[] = $row;
}

// ต้องหาจำนวนข้อมูลทั้งหมด (ไม่ใช่ filtered)
$resAll = mysqli_query($conn, "SELECT COUNT(*) as total FROM datatable");
$totalRecords = mysqli_fetch_assoc($resAll)['total'];

echo json_encode([
  "draw" => intval($_POST['draw'] ?? 1),
  "recordsTotal" => intval($totalRecords),
  "recordsFiltered" => intval($totalFiltered),
  "data" => $data
]);
?>
