<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Employee </title>
  <link rel="stylesheet" href="../forntend/style.css" />
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css" />
</head>
<body>
  <header>
    <h1>Employee Dashboard</h1>
  </header>

  <main>
    <div class="actions">
      <button type="button" class="btn-add" data-bs-toggle="modal" data-bs-target="#exampleModal">+เพิ่มพนักงาน</button>
    </div>

    <table id="employeeTable" class="display ">
      <thead>
        <tr>
          
          <th>ID</th>
          <th>First name</th>
          <th>Last name</th>
          <th>Email</th>
          <th>Position</th>
          <th>Gender</th>
          <th>Avatar</th>
          <th>Actions</th>
        </tr>
      </thead>
    </table>
  </main>
<img src="/table-employee/image/avatar.png" alt="Girl in a jacket" width="500" height="600">
  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" id="exampleModalLabel">เพิ่มพนักงาน</h4>
        </div>
        <div class="modal-body">
          <?php include 'add.php'; ?>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>  
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
  <script src="script.js"></script>