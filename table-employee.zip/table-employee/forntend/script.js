$(document).ready(function () {
  const table = $('#employeeTable').DataTable({
    processing: true,
    serverSide: true,
    ajax: {
      url: 'server_processing.php',
      type: 'POST',
    },
    columns: [
      { data: 'id' },
      { data: 'first_name' },
      { data: 'last_name' },
      { data: 'email' },
      { data: 'position' },
      { data: 'gender' }
    ]
  });
});
